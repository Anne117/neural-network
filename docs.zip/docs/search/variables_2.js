var searchData=
[
  ['case_5fsensitive_0',['case_sensitive',['../structdoctest_1_1_context_options.html#a08571475229452c2eb933da314a74dff',1,'doctest::ContextOptions']]],
  ['count_1',['count',['../structdoctest_1_1_context_options.html#a4651b5efbaf2ffc03d60fb4140d21dd3',1,'doctest::ContextOptions']]],
  ['cout_2',['cout',['../structdoctest_1_1_context_options.html#a1ee59adf440880ebd7b31516471ddcab',1,'doctest::ContextOptions']]],
  ['currenttest_3',['currentTest',['../structdoctest_1_1_context_options.html#a11af202a87045ba03482bf65c0a7f0bb',1,'doctest::ContextOptions']]]
];
