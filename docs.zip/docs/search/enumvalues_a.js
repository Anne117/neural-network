var searchData=
[
  ['red_0',['Red',['../namespacedoctest_1_1_color.html#a32e9eaf6013139846e848af6e6cf2b92a67beb0a8d937993ad8b8cf6a238271f9',1,'doctest::Color']]],
  ['relu_1',['ReLU',['../_net_work_for_video_one_2_activate_function_8h.html#a7ca203c77ee11fc0157a88dfd4e5f245ac2141c33518a5aa5233f0db6a9e163c8',1,'ActivateFunction.h']]]
];
