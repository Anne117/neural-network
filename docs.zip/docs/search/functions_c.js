var searchData=
[
  ['rand_0',['Rand',['../class_matrix.html#aedd6f31bc1a30a2c98cee0dc3d9b89f4',1,'Matrix::Rand()'],['../class_matrix.html#aedd6f31bc1a30a2c98cee0dc3d9b89f4',1,'Matrix::Rand()']]],
  ['react_1',['react',['../structdoctest_1_1detail_1_1_result_builder.html#a03686f862471728c2980d72e02980213',1,'doctest::detail::ResultBuilder::react()'],['../structdoctest_1_1detail_1_1_message_builder.html#a3a65c5e39a0c04ae8e2a7c34997a2e4d',1,'doctest::detail::MessageBuilder::react()']]],
  ['readdata_2',['ReadData',['../_net_work_for_video_one_2source_8cpp.html#a1555864b085371da44c6043797e432f6',1,'ReadData(string path, const data_NetWork &amp;data_NW, int &amp;examples):&#160;source.cpp'],['../source_8cpp.html#a3dcc631ef433aa58fa0dfad1f81768eb',1,'ReadData(string path, const data_NetWork &amp;data_NW, int &amp;examples):&#160;source.cpp']]],
  ['readdatanetwork_3',['ReadDataNetWork',['../_net_work_for_video_one_2source_8cpp.html#ad240537d76f63685e3f300ef45bc797c',1,'ReadDataNetWork(string path):&#160;source.cpp'],['../source_8cpp.html#ad240537d76f63685e3f300ef45bc797c',1,'ReadDataNetWork(string path):&#160;source.cpp']]],
  ['readweights_4',['ReadWeights',['../class_net_work.html#ab88a11065edac483037be19d4a9b9e0c',1,'NetWork::ReadWeights()'],['../class_net_work.html#ab88a11065edac483037be19d4a9b9e0c',1,'NetWork::ReadWeights()']]],
  ['registerexceptiontranslator_5',['registerExceptionTranslator',['../namespacedoctest.html#a8e23e6bb4c6982688652060dbe41385d',1,'doctest']]],
  ['registerexceptiontranslatorimpl_6',['registerExceptionTranslatorImpl',['../namespacedoctest_1_1detail.html#a3887426da16e0d12e6f0e270a767a6a5',1,'doctest::detail']]],
  ['registerreporter_7',['registerReporter',['../namespacedoctest.html#a9e878a811f7bf0a615b3a39de3004673',1,'doctest']]],
  ['registerreporterimpl_8',['registerReporterImpl',['../namespacedoctest_1_1detail.html#a828e011bb6028ab94eb14a3c7d8bd2c4',1,'doctest::detail']]],
  ['regtest_9',['regTest',['../namespacedoctest_1_1detail.html#a00f99edefb8490a8e2602d58c96431f4',1,'doctest::detail']]],
  ['report_5fquery_10',['report_query',['../structdoctest_1_1_i_reporter.html#ae7e30d1c2cd332094c66d39bf3a85e52',1,'doctest::IReporter']]],
  ['reportercreator_11',['reporterCreator',['../namespacedoctest_1_1detail.html#ac78a52271e895d8485356c4516a18685',1,'doctest::detail']]],
  ['result_12',['Result',['../structdoctest_1_1detail_1_1_result.html#ae38382da1a2d2f8e33aebc7da15febc9',1,'doctest::detail::Result::Result()=default'],['../structdoctest_1_1detail_1_1_result.html#ae4d2e8633aedaffa31f5c8b8530f522c',1,'doctest::detail::Result::Result(bool passed, const String &amp;decomposition=String())']]],
  ['resultbuilder_13',['ResultBuilder',['../structdoctest_1_1detail_1_1_result_builder.html#a135e00690002d376f3d050700a635680',1,'doctest::detail::ResultBuilder::ResultBuilder(assertType::Enum at, const char *file, int line, const char *expr, const char *exception_type=&quot;&quot;, const String &amp;exception_string=&quot;&quot;)'],['../structdoctest_1_1detail_1_1_result_builder.html#ab55660e3aaa5d8fccbe19360f65bb1f3',1,'doctest::detail::ResultBuilder::ResultBuilder(assertType::Enum at, const char *file, int line, const char *expr, const char *exception_type, const Contains &amp;exception_string)']]],
  ['rfind_14',['rfind',['../classdoctest_1_1_string.html#a6e22f4f3820de5ffdf82e0acc6646759',1,'doctest::String']]],
  ['run_15',['run',['../classdoctest_1_1_context.html#a8059b137ef41cbe6c5d8160806a3cc63',1,'doctest::Context']]]
];
