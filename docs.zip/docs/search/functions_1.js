var searchData=
[
  ['backpropogation_0',['BackPropogation',['../class_net_work.html#ad717355f96d22033d7c6edc741ed6750',1,'NetWork::BackPropogation(string expect)'],['../class_net_work.html#a817b07f408a65b036ce666b493e7f65b',1,'NetWork::BackPropogation(double expect)']]],
  ['binary_5fassert_1',['binary_assert',['../structdoctest_1_1detail_1_1_result_builder.html#aa920a0617a26939d7adcd1ba2dec0e85',1,'doctest::detail::ResultBuilder::binary_assert()'],['../namespacedoctest_1_1detail.html#a1e295c708d2de0e47ac89c1632211159',1,'doctest::detail::binary_assert()']]]
];
