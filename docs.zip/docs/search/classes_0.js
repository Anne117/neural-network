var searchData=
[
  ['activatefunction_0',['ActivateFunction',['../class_activate_function.html',1,'']]],
  ['approx_1',['Approx',['../structdoctest_1_1_approx.html',1,'doctest']]],
  ['assertdata_2',['AssertData',['../structdoctest_1_1_assert_data.html',1,'doctest']]]
];
