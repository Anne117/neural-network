var searchData=
[
  ['data_5finfo_0',['data_info',['../structdata__info.html',1,'']]],
  ['data_5fnetwork_1',['data_NetWork',['../structdata___net_work.html',1,'']]],
  ['deferred_5ffalse_2',['deferred_false',['../structdoctest_1_1detail_1_1deferred__false.html',1,'doctest::detail']]]
];
