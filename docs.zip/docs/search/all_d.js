var searchData=
[
  ['pixels_0',['pixels',['../structdata__info.html#a4f3467e8b98c67db4d196df4840f7697',1,'data_info::pixels'],['../structdata__info.html#ae78174a031a2cb4e5a5532a1ed9c68db',1,'data_info::pixels']]],
  ['printconfig_1',['PrintConfig',['../class_net_work.html#aba5a48e16e6129be80ff9600e38a05e9',1,'NetWork::PrintConfig()'],['../class_net_work.html#aba5a48e16e6129be80ff9600e38a05e9',1,'NetWork::PrintConfig()']]],
  ['printvalues_2',['PrintValues',['../class_net_work.html#a318cc86aaec59e6161d9afdd781388cd',1,'NetWork::PrintValues(int L)'],['../class_net_work.html#a318cc86aaec59e6161d9afdd781388cd',1,'NetWork::PrintValues(int L)']]]
];
