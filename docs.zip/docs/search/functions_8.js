var searchData=
[
  ['log_0',['log',['../structdoctest_1_1detail_1_1_result_builder.html#a2af75dd1d8db8d3aa949d78025854085',1,'doctest::detail::ResultBuilder::log()'],['../structdoctest_1_1detail_1_1_message_builder.html#a9bcc5d56e1764a7e07efebca55e43cce',1,'doctest::detail::MessageBuilder::log()']]],
  ['log_5fassert_1',['log_assert',['../structdoctest_1_1_i_reporter.html#a5bb54923eab233bb02f2fcfc178fa12a',1,'doctest::IReporter']]],
  ['log_5fmessage_2',['log_message',['../structdoctest_1_1_i_reporter.html#a2b2cb4f15aa7417d4903a0edc3147018',1,'doctest::IReporter']]]
];
