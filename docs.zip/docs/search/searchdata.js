var indexSectionsWithContent =
{
  0: "abcdefghilmnopqrstuvwy~",
  1: "abcdefhimnqrstu",
  2: "ds",
  3: "admnsu",
  4: "abcdefgilmoprstuw~",
  5: "abcdefghilmnopqrstv",
  6: "afinorst",
  7: "ae",
  8: "abcdefgilnrstwy",
  9: "o",
  10: "acdfgimrstw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Friends",
  10: "Macros"
};

