var searchData=
[
  ['activatefunc_0',['activateFunc',['../_net_work_for_video_one_2_activate_function_8h.html#a7ca203c77ee11fc0157a88dfd4e5f245',1,'ActivateFunction.h']]]
];
